// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.input;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class PointerDownAction implements PointerSourceAction {

  private final String type;
  private final long button;
  private Optional<Long> width;
  private Optional<Long> height;
  private Optional<Number> pressure;
  private Optional<Number> tangentialPressure;
  private Optional<Long> twist;
  private Optional<Number> altitudeAngle;
  private Optional<Number> azimuthAngle;

  public PointerDownAction(String type, long button) {
    if (!Objects.equals(type, "pointerDown")) {
      throw new BiDiException("type must be " + "pointerDown" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    if (button < 0L || button > 9007199254740991L) {
      throw new BiDiException("button must be >= 0 and <= 9007199254740991, got: " + button);
    }
    this.button = button;
    this.width = Optional.empty();
    this.height = Optional.empty();
    this.pressure = Optional.empty();
    this.tangentialPressure = Optional.empty();
    this.twist = Optional.empty();
    this.altitudeAngle = Optional.empty();
    this.azimuthAngle = Optional.empty();
  }

  PointerDownAction(String type, long button, Optional<Long> width, Optional<Long> height, Optional<Number> pressure, Optional<Number> tangentialPressure, Optional<Long> twist, Optional<Number> altitudeAngle, Optional<Number> azimuthAngle) {
    if (!Objects.equals(type, "pointerDown")) {
      throw new BiDiException("type must be " + "pointerDown" + ", got: " + type);
    }
    this.type = Objects.requireNonNull(type, "type is required");
    if (button < 0L || button > 9007199254740991L) {
      throw new BiDiException("button must be >= 0 and <= 9007199254740991, got: " + button);
    }
    this.button = button;
    if (width != null && width.isPresent() && (width.get() < 0L || width.get() > 9007199254740991L)) {
      throw new BiDiException("width must be >= 0 and <= 9007199254740991, got: " + width.get());
    }
    this.width = width != null ? width : Optional.empty();
    if (height != null && height.isPresent() && (height.get() < 0L || height.get() > 9007199254740991L)) {
      throw new BiDiException("height must be >= 0 and <= 9007199254740991, got: " + height.get());
    }
    this.height = height != null ? height : Optional.empty();
    if (pressure != null && pressure.isPresent() && !(pressure.get().doubleValue() >= 0d && pressure.get().doubleValue() <= 1d)) {
      throw new BiDiException("pressure must be >= 0 and <= 1, got: " + pressure.get());
    }
    this.pressure = pressure != null ? pressure : Optional.empty();
    if (tangentialPressure != null && tangentialPressure.isPresent() && !(tangentialPressure.get().doubleValue() >= -1d && tangentialPressure.get().doubleValue() <= 1d)) {
      throw new BiDiException("tangentialPressure must be >= -1 and <= 1, got: " + tangentialPressure.get());
    }
    this.tangentialPressure = tangentialPressure != null ? tangentialPressure : Optional.empty();
    if (twist != null && twist.isPresent() && (twist.get() < 0L || twist.get() > 359L)) {
      throw new BiDiException("twist must be >= 0 and <= 359, got: " + twist.get());
    }
    this.twist = twist != null ? twist : Optional.empty();
    if (altitudeAngle != null && altitudeAngle.isPresent() && !(altitudeAngle.get().doubleValue() >= 0d && altitudeAngle.get().doubleValue() <= 1.5707963267948966d)) {
      throw new BiDiException("altitudeAngle must be >= 0 and <= 1.5707963267948966, got: " + altitudeAngle.get());
    }
    this.altitudeAngle = altitudeAngle != null ? altitudeAngle : Optional.empty();
    if (azimuthAngle != null && azimuthAngle.isPresent() && !(azimuthAngle.get().doubleValue() >= 0d && azimuthAngle.get().doubleValue() <= 6.283185307179586d)) {
      throw new BiDiException("azimuthAngle must be >= 0 and <= 6.283185307179586, got: " + azimuthAngle.get());
    }
    this.azimuthAngle = azimuthAngle != null ? azimuthAngle : Optional.empty();
  }

  public PointerDownAction setWidth(Long width) {
    if (width != null && (width < 0L || width > 9007199254740991L)) {
      throw new BiDiException("width must be >= 0 and <= 9007199254740991, got: " + width);
    }
    this.width = Optional.ofNullable(width);
    return this;
  }

  public PointerDownAction setHeight(Long height) {
    if (height != null && (height < 0L || height > 9007199254740991L)) {
      throw new BiDiException("height must be >= 0 and <= 9007199254740991, got: " + height);
    }
    this.height = Optional.ofNullable(height);
    return this;
  }

  public PointerDownAction setPressure(Number pressure) {
    if (pressure != null && !(pressure.doubleValue() >= 0d && pressure.doubleValue() <= 1d)) {
      throw new BiDiException("pressure must be >= 0 and <= 1, got: " + pressure);
    }
    this.pressure = Optional.ofNullable(pressure);
    return this;
  }

  public PointerDownAction setTangentialPressure(Number tangentialPressure) {
    if (tangentialPressure != null && !(tangentialPressure.doubleValue() >= -1d && tangentialPressure.doubleValue() <= 1d)) {
      throw new BiDiException("tangentialPressure must be >= -1 and <= 1, got: " + tangentialPressure);
    }
    this.tangentialPressure = Optional.ofNullable(tangentialPressure);
    return this;
  }

  public PointerDownAction setTwist(Long twist) {
    if (twist != null && (twist < 0L || twist > 359L)) {
      throw new BiDiException("twist must be >= 0 and <= 359, got: " + twist);
    }
    this.twist = Optional.ofNullable(twist);
    return this;
  }

  public PointerDownAction setAltitudeAngle(Number altitudeAngle) {
    if (altitudeAngle != null && !(altitudeAngle.doubleValue() >= 0d && altitudeAngle.doubleValue() <= 1.5707963267948966d)) {
      throw new BiDiException("altitudeAngle must be >= 0 and <= 1.5707963267948966, got: " + altitudeAngle);
    }
    this.altitudeAngle = Optional.ofNullable(altitudeAngle);
    return this;
  }

  public PointerDownAction setAzimuthAngle(Number azimuthAngle) {
    if (azimuthAngle != null && !(azimuthAngle.doubleValue() >= 0d && azimuthAngle.doubleValue() <= 6.283185307179586d)) {
      throw new BiDiException("azimuthAngle must be >= 0 and <= 6.283185307179586, got: " + azimuthAngle);
    }
    this.azimuthAngle = Optional.ofNullable(azimuthAngle);
    return this;
  }

  public String getType() {
    return type;
  }

  public long getButton() {
    return button;
  }

  public Optional<Long> getWidth() {
    return width;
  }

  public Optional<Long> getHeight() {
    return height;
  }

  public Optional<Number> getPressure() {
    return pressure;
  }

  public Optional<Number> getTangentialPressure() {
    return tangentialPressure;
  }

  public Optional<Long> getTwist() {
    return twist;
  }

  public Optional<Number> getAltitudeAngle() {
    return altitudeAngle;
  }

  public Optional<Number> getAzimuthAngle() {
    return azimuthAngle;
  }

  @Override
  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("type", type);
    map.put("button", button);
    width.ifPresent(v -> map.put("width", v));
    height.ifPresent(v -> map.put("height", v));
    pressure.ifPresent(v -> map.put("pressure", v));
    tangentialPressure.ifPresent(v -> map.put("tangentialPressure", v));
    twist.ifPresent(v -> map.put("twist", v));
    altitudeAngle.ifPresent(v -> map.put("altitudeAngle", v));
    azimuthAngle.ifPresent(v -> map.put("azimuthAngle", v));
    return Collections.unmodifiableMap(map);
  }

}
