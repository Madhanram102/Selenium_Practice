// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class MozGetTreeParameters {

  private Optional<Long> maxDepth;
  private Optional<String> root;
  private Optional<MozScope> scope;

  public MozGetTreeParameters() {
    this.maxDepth = Optional.empty();
    this.root = Optional.empty();
    this.scope = Optional.empty();
  }

  MozGetTreeParameters(Optional<Long> maxDepth, Optional<String> root, Optional<MozScope> scope) {
    if (maxDepth != null && maxDepth.isPresent() && (maxDepth.get() < 0L || maxDepth.get() > 9007199254740991L)) {
      throw new BiDiException("maxDepth must be >= 0 and <= 9007199254740991, got: " + maxDepth.get());
    }
    this.maxDepth = maxDepth != null ? maxDepth : Optional.empty();
    this.root = root != null ? root : Optional.empty();
    this.scope = scope != null ? scope : Optional.empty();
  }

  public MozGetTreeParameters setMaxDepth(Long maxDepth) {
    if (maxDepth != null && (maxDepth < 0L || maxDepth > 9007199254740991L)) {
      throw new BiDiException("maxDepth must be >= 0 and <= 9007199254740991, got: " + maxDepth);
    }
    this.maxDepth = Optional.ofNullable(maxDepth);
    return this;
  }

  public MozGetTreeParameters setRoot(String root) {
    this.root = Optional.ofNullable(root);
    return this;
  }

  public MozGetTreeParameters setScope(MozScope scope) {
    this.scope = Optional.ofNullable(scope);
    return this;
  }

  public Optional<Long> getMaxDepth() {
    return maxDepth;
  }

  public Optional<String> getRoot() {
    return root;
  }

  public Optional<MozScope> getScope() {
    return scope;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    maxDepth.ifPresent(v -> map.put("maxDepth", v));
    root.ifPresent(v -> map.put("root", v));
    scope.ifPresent(v -> map.put("moz:scope", v.toWireValue()));
    return Collections.unmodifiableMap(map);
  }


  private static MozGetTreeParameters fromJson(Map<String, Object> map) {
    Json json = ConverterFunctions.JSON;
    Optional<Long> maxDepth = json.toType(json.toJson(map.get("maxDepth")), new TypeToken<Optional<Long>>() {}.getType());
    Optional<String> root = json.toType(json.toJson(map.get("root")), new TypeToken<Optional<String>>() {}.getType());
    Optional<MozScope> scope = json.toType(json.toJson(map.get("moz:scope")), new TypeToken<Optional<MozScope>>() {}.getType());
    return new MozGetTreeParameters(maxDepth, root, scope);
  }
}
