// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

// This file is generated. Do not edit — regenerate via BiDiGenerator.

package org.openqa.selenium.bidi.protocol.browsingcontext;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.BiDiException;
import org.openqa.selenium.bidi.ConverterFunctions;
import org.openqa.selenium.json.Json;
import org.openqa.selenium.json.TypeToken;
import org.openqa.selenium.json.WarnOnUnknownFields;

/**
 * This is an unsupported API. No compatibility guarantees are provided.
 * It tracks the W3C WebDriver BiDi specification directly. As the specification
 * evolves, this API will change or be removed without prior notice.
 */
@Beta
@ApiStatus.Internal
public class ImageFormat {

  private final String type;
  private Optional<Number> quality;

  public ImageFormat(String type) {
    this.type = Objects.requireNonNull(type, "type is required");
    this.quality = Optional.empty();
  }

  ImageFormat(String type, Optional<Number> quality) {
    this.type = Objects.requireNonNull(type, "type is required");
    if (quality != null && quality.isPresent() && !(quality.get().doubleValue() >= 0d && quality.get().doubleValue() <= 1d)) {
      throw new BiDiException("quality must be >= 0 and <= 1, got: " + quality.get());
    }
    this.quality = quality != null ? quality : Optional.empty();
  }

  public ImageFormat setQuality(Number quality) {
    if (quality != null && !(quality.doubleValue() >= 0d && quality.doubleValue() <= 1d)) {
      throw new BiDiException("quality must be >= 0 and <= 1, got: " + quality);
    }
    this.quality = Optional.ofNullable(quality);
    return this;
  }

  public String getType() {
    return type;
  }

  public Optional<Number> getQuality() {
    return quality;
  }

  public Map<String, Object> toMap() {
    Map<String, Object> map = new LinkedHashMap<>();
    map.put("type", type);
    quality.ifPresent(v -> map.put("quality", v));
    return Collections.unmodifiableMap(map);
  }

}
